<html>
	<head>
		<title>Hospital Management System</title>
		<link href="css/style.css" rel="stylesheet" type="text/css"  media="all" />
		<link href='http://fonts.googleapis.com/css?family=Ropa+Sans' rel='stylesheet' type='text/css' />
		<link rel="stylesheet" href="css/slides.css" />
		<link rel="stylesheet" href="css/custom-select.css" />
		<link rel="stylesheet" href="css/button.css" />
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
		<script src="js/slides.min.js"></script>
		
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
	</head>
	
	<body>
	
	
	
	
		<script>
			$(function (){
			    $("#slider1").slides({
				maxwidth: 1600,
				speed:1000
				});
			});
		</script>
	
		
	
		<div class="header"><div class="wrap">
		
			<div class="logo">
				<img src="images/hmslogo.png" alt="logo" />
				<a href="index.php" style="font-size:30px;">Hospital Management System</a>
			</div>
			<div class="top-nav">
				<ul>
					<li class="active"><a href="index.html" style="font-size:14px;">Home</a></li>
					<li><a href="contact.php" style="font-size:14px;">Contact</a></li>
				</ul>
			</div>
		</div></div>
		
		
		<div class="clear"> </div>
		
		
		
		<div class="SlidesShow">
			<ul class="slides" id="slider1">
				<li><img src="images/img.jpg"></li>
			    <li><img src="images/img2.jpg"></li>
				<li><img src="images/img3.jpg"></li>
			    <li><img src="images/img1.jpg"></li>
			</ul>
		</div>
		
		<div class="clear"> </div>
			
			
			
		<div class="content-grids">
			<div class="wrap">
				<div class="section group">
					<div class="listview_1_of_3 images_1_of_3">
						<div class="listimg listimg_1_of_2">
							<img src="images/patient.png">
						</div>
						<div class="text list_1_of_2">
							<h3>Patients</h3>
								<p>Register & Book Appointment</p>
							<div class="button"><span><a href="user-login.php">Click Here</a></span></div>
						</div>
					</div>

					<div class="listview_1_of_3 images_1_of_3">
						<div class="listimg listimg_1_of_2">
						  <img src="images/doctor.png">
						</div>
						<div class="text list_1_of_2">
								<h3>Doctors Login</h3>
								<div class="button"><span><a href="doctor/">Click Here</a></span></div>
						</div>
					</div>


					<div class="listview_1_of_3 images_1_of_3">
						<div class="listimg listimg_1_of_2">
							<img src="images/administrator.png">
						</div>
						<div class="text list_1_of_2">
							<h3>Admin Login</h3>

							<div class="button"><span><a href="admin">Click Here</a></span></div>
						</div>
					</div>
				</div>
		    </div>
		</div>
					
		<div class="clear"> </div>
		
		
		
		<div class="content-grids">
			<div class="wrap">
				<div class="section group">
					<div class="listview_1_of_3 images_1_of_3">
						<div class="listimg listimg_1_of_2">
							<img src="images/employee.png">
						</div>
						<div class="text list_1_of_2">
							<h3>Employee</h3>
								<p>Workers and Labo</p>
							<div class="button"><span><a href="user-login.php">Click Here</a></span></div>
						</div>
					</div>
					<div class="listview_1_of_3 images_1_of_3">
						<div class="listimg listimg_1_of_2">
							<img src="images/labotory.png">
						</div>
						<div class="text list_1_of_2">
							<h3>Laboratory</h3>
							<p>Reports and Test Info</p>
							<div class="button"><span><a href="doctor/">Click Here</a></span></div>
						</div>
					</div>


					<div class="listview_1_of_3 images_1_of_3">
						<div class="listimg listimg_1_of_2">
						  <img src="images/info.png">
						</div>
						<div class="text list_1_of_2">
							<h3>Other Informations</h3>
							<div class="button"><span><a href="admin">Click Here</a></span></div>
						</div>
					</div>
					
				</div>
			</div>
		</div>
		   
		   
		   
		      
		<div class="wrap">
			<div class="content-box">
				<div class="section group">
					<div class="col_1_of_3 span_1_of_3 frist"></div>
					<div class="col_1_of_3 span_1_of_3 second"></div>
					<div class="col_1_of_3 span_1_of_3 frist"></div>
				</div>
		   </div>
		</div>
		<div class="clear"> </div>
		
		
		<div class="footer">
		   	<div class="wrap">
				<div class="footer-right">
					<div class="top-nav">
						<ul>
							<li class="active"><a href="index.html">Home</a></li>
							<li><a href="contact.php">contact</a></li>
						</ul>
					</div>
				</div>
				<div class="clear"> </div>
			</div>
		</div>
	</body>
</html>