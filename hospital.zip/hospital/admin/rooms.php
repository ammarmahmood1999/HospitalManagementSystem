<?php
session_start();
include('include/config.php');
$currentTime = date( 'd-m-Y h:i:s A', time () );
$count=100;
	if(isset($_POST['submit']))
	{	$count=100;
		$result=mysqli_query($conn, "select * from room");
		$count = mysqli_num_rows($result);
        if($count==0){
			$_SESSION['errmsg']="Room booking not updated successfully !!";
        }
		if($count==1){
			mysqli_query($conn,"update room set status = '1' where id = $_POST[roomid]");
		}
		$count=100;
    }
		
?>
<html>
	<head>
		<title>	Manage Rooms</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<meta content="" name="description" />
		<meta content="" name="author" />
		<link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
		<link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="vendor/themify-icons/themify-icons.min.css">
		<link rel="stylesheet" href="assets/css/styles.css">
		<link rel="stylesheet" href="assets/css/plugins.css">
		<link rel="stylesheet" href="assets/css/themes/theme-1.css" id="skin_color" />
	</head>
	<body>
		<div id="app">		
			<div class="app-content">
				
				<?php include('include/header.php');?>
					
				<div class="main-content" >
					<div class="wrap-content container" id="container">
						<section id="page-title">
							<div class="row">
								<div class="col-sm-8">
									<h1 class="mainTitle">Manage Rooms</h1>
																	</div>
								
								<?php include('roomlist.php');?>
							</div>
						</section>
						<div class="container-fluid container-fullw bg-white">
							<div class="row">
								<div class="col-md-12">
									
									<div class="row margin-top-30">
										<div class="col-lg-6 col-md-12">
											<div class="panel panel-white">
												<div class="panel-heading">
													<h5 class="panel-title">Manage Rooms</h5>
												</div>
												
												
												<div class="panel-body">
												<p style="color:blue;"><?php echo htmlentities($_SESSION['msg']);?>
												<?php echo htmlentities($_SESSION['msg']="");?></p>
												
												<p style="color:red;"><?php echo htmlentities($_SESSION['errmsg']);?>
												<?php echo htmlentities($_SESSION['errmsg']="");?></p>
												
												
												
												
													<form role="form" name="dcotorspcl" method="post" >
														<div class="form-group">
															<label for="exampleInputEmail1">
																Enter Doctor Id.//:
															</label>
					
					
															<input type="textfield" name="id" class="id" required="">
														</div>
														<div class="form-group">
															<label for="exampleInputEmail1">
																Edit Doctor Specialization
															</label>
					
					
														<input type="textfield" name="doctorspecilization" class="form-control" required="">
														</div>
												
														
														<button type="submit" name="submit" class="btn btn-o btn-primary">
															Update
														</button>
														
													</form>
													
													
													
												</div>
											</div>
										</div>		
									</div>
								</div>
									<div class="col-lg-12 col-md-12">
										<div class="panel panel-white">
														
										</div>
									</div>
							</div>						
						</div>
					</div>
				</div>
						
					</div>
				</div>
			</div>
	</body>
</html>
