<?php
session_start();
include('include/config.php');
?>
<html>
	<head>
		<title>Admin Page</title>
		
		<link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
		<link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="vendor/themify-icons/themify-icons.min.css">
		
		<link href="vendor/bootstrap-datepicker/bootstrap-datepicker3.standalone.min.css" rel="stylesheet" media="screen">
		<link href="vendor/bootstrap-timepicker/bootstrap-timepicker.min.css" rel="stylesheet" media="screen">
		<link rel="stylesheet" href="css/styles.css">
		<link rel="stylesheet" href="css/plugins.css">
		
		
		<link href="css/style.css" rel="stylesheet" type="text/css"  media="all" />
		<link href='http://fonts.googleapis.com/css?family=Ropa+Sans' rel='stylesheet' type='text/css' />
		<link rel="stylesheet" href="css/slides.css" />
		<link rel="stylesheet" href="css/custom-select.css" />
		<link rel="stylesheet" href="css/button.css" />
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>


	</head>
	<body>
		<div id="app">		
			<div class="app-content">
				
				<?php include('include/header.php');?>
				<div class="main-content" >
					<div class="wrap-content container" id="container">
						<section id="page-title">
							<div class="row">
								<div class="col-sm-8">
									<h1 class="mainTitle">Dashboard</h1>
								</div>
							</div>
						</section>
						
						
						
						<div class="content-grids">
					<div class="wrap">
					<div class="section group">
					<div class="listview_1_of_3 images_1_of_3">
						<div class="listimg listimg_1_of_2">
							<img src="images/managepatient.png">
						</div>
						<div class="text list_1_of_2">
							<h3>Manage Patients</h3>
							<div class="button"><span><a href="edit-doctor-specialization.php">Click Here</a></span></div>
						</div>
					</div>

					<div class="listview_1_of_3 images_1_of_3">
						<div class="listimg listimg_1_of_2">
						  <img src="images/editstudy.png">
						</div>
						<div class="text list_1_of_2">
								<h3>Edit Doctor Specialization</h3>
								<div class="button"><span><a href="edit-doctor-specialization.php">Click Here</a></span></div>
						</div>
					</div>


					<div class="listview_1_of_3 images_1_of_3">
						<div class="listimg listimg_1_of_2">
							<img src="images/edit.png">
						</div>
						<div class="text list_1_of_2">
							<h3>Add Doctors Info</h3>
							<div class="button"><span><a href="admin/index.php">Click Here</a></span></div>
						</div>
					</div>
				</div>
		    </div>
		</div>
					
		<div class="clear"> </div>
		
		
		
		<div class="content-grids">
			<div class="wrap">
				<div class="section group">
					<div class="listview_1_of_3 images_1_of_3">
						<div class="listimg listimg_1_of_2">
							<img src="images/managedoctor.png">
						</div>
						<div class="text list_1_of_2">
							<h3>Manage Departments</h3>
							<div class="button"><span><a href="user-login.php">Click Here</a></span></div>
						</div>
					</div>
					<div class="listview_1_of_3 images_1_of_3">
						<div class="listimg listimg_1_of_2">
							<img src="images/apphistory.png">
						</div>
						<div class="text list_1_of_2">
							<h3>Appointment</h3>
							<div class="button"><span><a href="appointment-history.php">Click Here</a></span></div>
						</div>
					</div>


					<div class="listview_1_of_3 images_1_of_3">
						<div class="listimg listimg_1_of_2">
						  <img src="images/manageemployee.png">
						</div>
						<div class="text list_1_of_2">
							<h3>Manage Employee</h3>
							<div class="button"><span><a href="admin">Click Here</a></span></div>
						</div>
					</div>
					
				</div>
			</div>
		</div>
		
		
		
		
		<div class="clear"> </div>
		
		
		
		<div class="content-grids">
			<div class="wrap">
				<div class="section group">
					<div class="listview_1_of_3 images_1_of_3">
						<div class="listimg listimg_1_of_2">
							<img src="images/room.png">
						</div>
						<div class="text list_1_of_2">
							<h3>Room Appointment</h3>
							<div class="button"><span><a href="rooms.php">Click Here</a></span></div>
						</div>
					</div>
					<div class="listview_1_of_3 images_1_of_3">
						<div class="listimg listimg_1_of_2">
							<img src="images/medicine.png">
						</div>
						<div class="text list_1_of_2">
							<h3>Manage Medicine</h3>
							<div class="button"><span><a href="appointment-history.php">Click Here</a></span></div>
						</div>
					</div>


					<div class="listview_1_of_3 images_1_of_3">
						<div class="listimg listimg_1_of_2">
						  <img src="images/testrepote.png">
						</div>
						<div class="text list_1_of_2">
							<h3>Test Form</h3>
							<div class="button"><span><a href="admin">Click Here</a></span></div>
						</div>
					</div>
					
				</div>
			</div>
		</div>
		
		<div class="wrap">
			<div class="content-box">
				<div class="section group">
					<div class="col_1_of_3 span_1_of_3 frist"></div>
					<div class="col_1_of_3 span_1_of_3 second"></div>
					<div class="col_1_of_3 span_1_of_3 second"></div>
				</div>
		   </div>
		</div>
		<div class="clear"> </div>
					</div>
				</div>
			</div>
	</body>
</html>
