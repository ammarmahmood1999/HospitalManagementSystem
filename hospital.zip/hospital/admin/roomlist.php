<div class="container-fluid container-fullw bg-white">
						

	<div class="row">
		<div class="col-md-12">
			<table class="table table-hover" id="sample-table-1">
						<thead>
								<tr>
									<th class="center">#</th>
									<th class="hidden-xs">Room ID</th>
									<th>Room Categori</th>
									<th>Fee/Charges</th>
									<th>Status</th>						
							</tr>
						</thead>
						<tbody>
						<?php										
							include('include/config.php');
							$x=1;
							$sql=mysqli_query($conn,"select * from room");
							while($row=mysqli_fetch_array($sql))
							{
							
						?>

						<tr>
							<td class="center"><?php echo $x; ?>.</td>
							<td class="hidden-xs"><?php echo $row['roomid']; ?></td>
							<td class="hidden-xs"><?php echo $row['roomtype'];?></td>
							<td><?php echo $row['roomcharges'];?></td>
							<td><?php echo $row['status'];?></td>
							<td>

							</td>
						</tr>					
					<?php 
						$x=$x+1;
					}?>							
				</tbody>
			</table>
		</div>
	</div>
</div>