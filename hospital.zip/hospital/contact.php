<html>
	<head>
		<title>Contact Us</title>
		<img src="imagepng" />
		</title>
		<link href="css/style.css" rel="stylesheet" type="text/css"  media="all" />
		<link href='http://fonts.googleapis.com/css?family=Ropa+Sans' rel='stylesheet' type='text/css'>
	</head>
	<body>
	
	
	
		<div class="header">
				<div class="wrap">
					<div class="logo">
						<img src="images/hmslogo.png" alt="logo">
						<a href="index.html" style ="font-size:30px;">Hospital Management System</a>
					</div>
				<div class="top-nav">
					<ul>
						<li><a href="index.html" style="font-size:14px;">Home</a></li>
						<li class="active"><a href="contact.php" style="font-size:14px;">contact</a></li>
					</ul>
				</div>
				<div class="clear"> </div>
			</div>
		</div>
		
		
		
		
		
		<div class="clear"> </div>
		
		<div class="wrap">
		   	<div class="contact">
		   	<div class="section group">
				<div class="col span_1_of_3">

      			<div>
						<style>
						 h2{
								
						}
						 
						</style>
				     	<h2 >Hospital Address  :</h2>
						    	<p>R1/102 DHA phase 5,</p>
						   		<p>Fast,Karachi</p>
						   		<p>Pakistan</p>
				   		<p>Phone:03352685318</p>
				   		<p>facebook:<span>ammarmahmood28@yahoo.com<span></p>
				 	 	<p>Email: <span>ammarmahmood28@gmail.com</span></p>

				   </div>
				</div>
				<div class="col span_2_of_3">
				  <div class="contact-form">
				  	<h2>Contact Us</h2>
					    <form>
					    	<div>
						    	<span><label>NAME</label></span>
						    	<span><input type="text" value=""></span>
						    </div>
						    <div>
						    	<span><label>E-MAIL</label></span>
						    	<span><input type="text" value=""></span>
						    </div>
						    <div>
						     	<span><label>MOBILE.NO</label></span>
						    	<span><input type="text" value=""></span>
						    </div>
						    <div>
						    	<span><label>SUBJECT</label></span>
						    	<span><textarea> </textarea></span>
						    </div>
						   <div>
						   		<span><input type="submit" value="Submit"></span>
						  </div>
					    </form>
				    </div>
  				</div>
			  </div>
			  	 <div class="clear"> </div>
	</div>
	<div class="clear"> </div>
			</div>
	      <div class="clear"> </div>
		  
		  
		  
		  
		<div class="footer">
		   	<div class="wrap">
				<div class="top-nav">
		   			<ul>
						<li><a href="index.html" style="font-size:14px;">Home</a></li>
						<li class="active"><a href="contact.php" style="font-size:14px;">Contact</a></li>
					</ul>
		   	</div>

		   	<div class="clear"> </div>
			</div>
		</div>
	</body>
</html>
